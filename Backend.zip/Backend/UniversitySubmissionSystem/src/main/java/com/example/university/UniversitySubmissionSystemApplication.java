package com.example.university;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class UniversitySubmissionSystemApplication {

	public static void main(String[] args) {
		SpringApplication.run(UniversitySubmissionSystemApplication.class, args);
	}
}

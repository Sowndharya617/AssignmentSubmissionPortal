    package com.example.university.model;

    public class GradeSubmissionRequest {
        private String grade;

        // Getter and Setter
        public String getGrade() { return grade; }
        public void setGrade(String grade) { this.grade = grade; }
    }
    